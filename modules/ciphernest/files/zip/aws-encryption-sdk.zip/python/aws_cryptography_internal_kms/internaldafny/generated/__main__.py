# Dafny program the_program compiled into Python
import sys
from typing import Callable, Any, TypeVar, NamedTuple
from math import floor
from itertools import count

import aws_cryptography_internal_kms.internaldafny.generated.module_ as module_
import _dafny as _dafny

